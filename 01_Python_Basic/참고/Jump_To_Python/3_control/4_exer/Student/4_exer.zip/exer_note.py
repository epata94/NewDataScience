elif COND:
    if age in range(61, 66)
        print("%d" %(customer[level] * 0.9)*0.95)
    print("%d" %(customer[level] * 0.9))
