i = 0
while True:
    i += 1
    if i > 5: break
    print("*"*i)
