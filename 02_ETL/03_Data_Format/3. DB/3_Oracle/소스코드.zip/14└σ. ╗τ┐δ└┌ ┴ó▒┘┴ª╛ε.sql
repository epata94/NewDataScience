CREATE  USER    heojk
IDENTIFIED  BY  jinkyoung;

select * from employees;
select * from departments;